---
name: videos-watchlist
description: See top performing videos from your watchlist
---
Show me the top performing videos from my watchlist. $ARGUMENTS

Use the `search_my_videos` tool. If the user provided a topic or filter context above, factor that into the search (pass the topic as a `query` and parse any natural-language filter words). Otherwise, use default settings.

If the results appear as interactive cards, don't list the videos again; otherwise present them as a list. Either way, lead with the insights and ground them in specific videos by their Sandcastles links.
