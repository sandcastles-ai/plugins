---
name: whoami
description: Identify the connected Sandcastles user, active workspace, and available tools.
---
Tell me who I'm logged in as in Sandcastles, what workspace I'm currently in, and what tools are available.
